service.subtitles.dings
==========================

Tries to find a sub next to the file if its http with the same filename but srt ending