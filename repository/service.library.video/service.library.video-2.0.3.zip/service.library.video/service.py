""" Rootfile forservice """
from __future__ import (absolute_import, division,
                        print_function, unicode_literals)
from builtins import *

from resources.lib.service_entry import Service

def run():
    service = Service()

    try:
        service.run()
    except Exception as e:
        service.shutdown()

if __name__ == '__main__':
    run()
