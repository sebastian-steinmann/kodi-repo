xbmcvfs
=======

.. automodule:: xbmcvfs

   
   
   .. rubric:: Functions

   .. autosummary::
   
      copy
      delete
      exists
      listdir
      mkdir
      mkdirs
      rename
      rmdir
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      File
      Stat
   
   

   
   
   