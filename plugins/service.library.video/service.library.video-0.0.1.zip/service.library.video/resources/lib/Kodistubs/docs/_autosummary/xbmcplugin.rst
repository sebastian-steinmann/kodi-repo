xbmcplugin
==========

.. automodule:: xbmcplugin

   
   
   .. rubric:: Functions

   .. autosummary::
   
      addDirectoryItem
      addDirectoryItems
      addSortMethod
      endOfDirectory
      getSetting
      setContent
      setPluginCategory
      setPluginFanart
      setProperty
      setResolvedUrl
      setSetting
   
   

   
   
   

   
   
   