xbmcaddon
=========

.. automodule:: xbmcaddon

   
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Addon
   
   

   
   
   